// Event - on button submit

submitButton = document.getElementById("create_btn");

document.addEventListener(submitButton, onclick, function () {});
