from flask_webapp.db_config.db import create_app
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import ForeignKey

db = create_app()
    


